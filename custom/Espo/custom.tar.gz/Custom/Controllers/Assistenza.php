<?php

namespace Espo\Custom\Controllers;

class Assistenza extends \Espo\Core\Templates\Controllers\Base
{
}
