<?php

namespace Espo\Custom\Controllers;

class Prepagato extends \Espo\Core\Templates\Controllers\Base
{
}
