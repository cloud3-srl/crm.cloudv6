<?php

namespace Espo\Custom\Entities;

class Prepagato extends \Espo\Core\Templates\Entities\Base
{
    protected $entityType = "Prepagato";
}
