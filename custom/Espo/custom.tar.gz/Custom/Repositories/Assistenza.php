<?php

namespace Espo\Custom\Repositories;

class Assistenza extends \Espo\Core\Templates\Repositories\Base
{
}
