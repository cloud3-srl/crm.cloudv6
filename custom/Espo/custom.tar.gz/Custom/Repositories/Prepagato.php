<?php

namespace Espo\Custom\Repositories;

class Prepagato extends \Espo\Core\Templates\Repositories\Base
{
}
