<?php

namespace Espo\Custom\Services;

class Assistenza extends \Espo\Core\Templates\Services\Base
{
}
