<?php

namespace Espo\Custom\Services;

class Prepagato extends \Espo\Core\Templates\Services\Base
{
}
